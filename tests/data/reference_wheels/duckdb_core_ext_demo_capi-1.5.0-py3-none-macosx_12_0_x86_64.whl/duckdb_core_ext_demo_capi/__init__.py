"""DuckDB demo_capi extension, DuckDB 1.5.0, osx_amd64."""

import os

_EXTENSIONS_DIR = ".duckdb_extensions"


def get_extensions_dir():
    """The shared extension directory in site-packages that DuckDB can search and install into."""
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), _EXTENSIONS_DIR)


def get_extension_load_path():
    """The extension binary, for LOAD by path."""
    return os.path.join(get_extensions_dir(), "v1.5.0", "osx_amd64", "demo_capi.duckdb_extension")
